# slack-financial-analysis-chatbot
chat bot using llm technology 
